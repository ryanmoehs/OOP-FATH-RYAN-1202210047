import java.util.Scanner;

public class Server {

    public static void main(String[] args) {
        // TODO Create Database

        // TODO Create Menu

        // TODO Insert Menu to Database

        // TODO Display Main Menu and User must be Register First

        // TODO Create User from register in Main Menu

        // TODO Display Menu

    }
}
